﻿
namespace Program_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Passengers = new System.Windows.Forms.Label();
            this.Distance = new System.Windows.Forms.Label();
            this.CarTyp = new System.Windows.Forms.Label();
            this.PassengersTxt = new System.Windows.Forms.TextBox();
            this.DistanceTxt = new System.Windows.Forms.TextBox();
            this.CarType = new System.Windows.Forms.ComboBox();
            this.CompanyACostLabel = new System.Windows.Forms.Label();
            this.CompanyBCostLabel = new System.Windows.Forms.Label();
            this.CompanyCCostsLabel = new System.Windows.Forms.Label();
            this.LowestCompanyCostTxt = new System.Windows.Forms.Label();
            this.ACostsText = new System.Windows.Forms.Label();
            this.BCostsText = new System.Windows.Forms.Label();
            this.CCostsText = new System.Windows.Forms.Label();
            this.CalculateBttn = new System.Windows.Forms.Button();
            this.ResultsLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Passengers
            // 
            this.Passengers.AutoSize = true;
            this.Passengers.Location = new System.Drawing.Point(34, 41);
            this.Passengers.Name = "Passengers";
            this.Passengers.Size = new System.Drawing.Size(201, 25);
            this.Passengers.TabIndex = 0;
            this.Passengers.Text = "Passengers (1-12) :";
            // 
            // Distance
            // 
            this.Distance.AutoSize = true;
            this.Distance.Location = new System.Drawing.Point(33, 100);
            this.Distance.Name = "Distance";
            this.Distance.Size = new System.Drawing.Size(202, 25);
            this.Distance.TabIndex = 1;
            this.Distance.Text = "Distance (in Miles) :";
            // 
            // CarTyp
            // 
            this.CarTyp.AutoSize = true;
            this.CarTyp.Location = new System.Drawing.Point(123, 150);
            this.CarTyp.Name = "CarTyp";
            this.CarTyp.Size = new System.Drawing.Size(112, 25);
            this.CarTyp.TabIndex = 2;
            this.CarTyp.Text = "Car Type :";
            // 
            // PassengersTxt
            // 
            this.PassengersTxt.Location = new System.Drawing.Point(258, 41);
            this.PassengersTxt.Name = "PassengersTxt";
            this.PassengersTxt.Size = new System.Drawing.Size(152, 31);
            this.PassengersTxt.TabIndex = 3;
            // 
            // DistanceTxt
            // 
            this.DistanceTxt.Cursor = System.Windows.Forms.Cursors.Default;
            this.DistanceTxt.Location = new System.Drawing.Point(258, 100);
            this.DistanceTxt.Name = "DistanceTxt";
            this.DistanceTxt.Size = new System.Drawing.Size(152, 31);
            this.DistanceTxt.TabIndex = 4;
            // 
            // CarType
            // 
            this.CarType.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.CarType.FormattingEnabled = true;
            this.CarType.Items.AddRange(new object[] {
            "Limousine",
            "Luxury",
            "Mid-tier",
            "Green",
            "Economy",
            "",
            ""});
            this.CarType.Location = new System.Drawing.Point(297, 150);
            this.CarType.Name = "CarType";
            this.CarType.Size = new System.Drawing.Size(113, 33);
            this.CarType.TabIndex = 5;
            // 
            // CompanyACostLabel
            // 
            this.CompanyACostLabel.AutoSize = true;
            this.CompanyACostLabel.Location = new System.Drawing.Point(417, 230);
            this.CompanyACostLabel.Name = "CompanyACostLabel";
            this.CompanyACostLabel.Size = new System.Drawing.Size(179, 25);
            this.CompanyACostLabel.TabIndex = 6;
            this.CompanyACostLabel.Text = "Company A Cost:";
            // 
            // CompanyBCostLabel
            // 
            this.CompanyBCostLabel.AutoSize = true;
            this.CompanyBCostLabel.Location = new System.Drawing.Point(417, 282);
            this.CompanyBCostLabel.Name = "CompanyBCostLabel";
            this.CompanyBCostLabel.Size = new System.Drawing.Size(179, 25);
            this.CompanyBCostLabel.TabIndex = 7;
            this.CompanyBCostLabel.Text = "Company B Cost:";
            // 
            // CompanyCCostsLabel
            // 
            this.CompanyCCostsLabel.AutoSize = true;
            this.CompanyCCostsLabel.Location = new System.Drawing.Point(417, 333);
            this.CompanyCCostsLabel.Name = "CompanyCCostsLabel";
            this.CompanyCCostsLabel.Size = new System.Drawing.Size(180, 25);
            this.CompanyCCostsLabel.TabIndex = 8;
            this.CompanyCCostsLabel.Text = "Company C Cost:";
            // 
            // LowestCompanyCostTxt
            // 
            this.LowestCompanyCostTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LowestCompanyCostTxt.Location = new System.Drawing.Point(396, 377);
            this.LowestCompanyCostTxt.Name = "LowestCompanyCostTxt";
            this.LowestCompanyCostTxt.Size = new System.Drawing.Size(376, 49);
            this.LowestCompanyCostTxt.TabIndex = 9;
            this.LowestCompanyCostTxt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ACostsText
            // 
            this.ACostsText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ACostsText.Location = new System.Drawing.Point(611, 220);
            this.ACostsText.Name = "ACostsText";
            this.ACostsText.Size = new System.Drawing.Size(124, 35);
            this.ACostsText.TabIndex = 10;
            // 
            // BCostsText
            // 
            this.BCostsText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BCostsText.Location = new System.Drawing.Point(611, 272);
            this.BCostsText.Name = "BCostsText";
            this.BCostsText.Size = new System.Drawing.Size(124, 35);
            this.BCostsText.TabIndex = 11;
            // 
            // CCostsText
            // 
            this.CCostsText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CCostsText.Location = new System.Drawing.Point(611, 323);
            this.CCostsText.Name = "CCostsText";
            this.CCostsText.Size = new System.Drawing.Size(124, 35);
            this.CCostsText.TabIndex = 12;
            // 
            // CalculateBttn
            // 
            this.CalculateBttn.Location = new System.Drawing.Point(86, 364);
            this.CalculateBttn.Name = "CalculateBttn";
            this.CalculateBttn.Size = new System.Drawing.Size(211, 50);
            this.CalculateBttn.TabIndex = 13;
            this.CalculateBttn.Text = "Calculate Button";
            this.CalculateBttn.UseVisualStyleBackColor = true;
            this.CalculateBttn.Click += new System.EventHandler(this.CalculateBttn_Click);
            // 
            // ResultsLabel
            // 
            this.ResultsLabel.AutoSize = true;
            this.ResultsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResultsLabel.Location = new System.Drawing.Point(538, 181);
            this.ResultsLabel.Name = "ResultsLabel";
            this.ResultsLabel.Size = new System.Drawing.Size(91, 25);
            this.ResultsLabel.TabIndex = 14;
            this.ResultsLabel.Text = "Results";
            this.ResultsLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ResultsLabel);
            this.Controls.Add(this.CalculateBttn);
            this.Controls.Add(this.CCostsText);
            this.Controls.Add(this.BCostsText);
            this.Controls.Add(this.ACostsText);
            this.Controls.Add(this.LowestCompanyCostTxt);
            this.Controls.Add(this.CompanyCCostsLabel);
            this.Controls.Add(this.CompanyBCostLabel);
            this.Controls.Add(this.CompanyACostLabel);
            this.Controls.Add(this.CarType);
            this.Controls.Add(this.DistanceTxt);
            this.Controls.Add(this.PassengersTxt);
            this.Controls.Add(this.CarTyp);
            this.Controls.Add(this.Distance);
            this.Controls.Add(this.Passengers);
            this.Name = "Form1";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Passengers;
        private System.Windows.Forms.Label Distance;
        private System.Windows.Forms.Label CarTyp;
        private System.Windows.Forms.TextBox PassengersTxt;
        private System.Windows.Forms.TextBox DistanceTxt;
        private System.Windows.Forms.ComboBox CarType;
        private System.Windows.Forms.Label CompanyACostLabel;
        private System.Windows.Forms.Label CompanyBCostLabel;
        private System.Windows.Forms.Label CompanyCCostsLabel;
        private System.Windows.Forms.Label LowestCompanyCostTxt;
        private System.Windows.Forms.Label ACostsText;
        private System.Windows.Forms.Label BCostsText;
        private System.Windows.Forms.Label CCostsText;
        private System.Windows.Forms.Button CalculateBttn;
        private System.Windows.Forms.Label ResultsLabel;
    }
}

