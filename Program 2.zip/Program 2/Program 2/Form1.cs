﻿//Grading ID:    S5041
//Program Number:#2
//Due Date:      10/23/2021
//Course Section:50 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculateBttn_Click(object sender, EventArgs e)
        {
            
            //Company A Constants
            const int APassengers = 2;
            const double ADistance = .02;
            //Company B Constants
             const double BDistance = .1;
            //Company C Constants
            const double CPassengers = .25;
            const int CCarType= 20;
            int ACarType = 0;//company A cartype place holder
            double DistanceC = 0;//company C Distance place holder
            int BCarType = 0;//company B Car type place holder
            int PassengerB = 0;//company B passenger place holder

            
            
            //if statements for Cartype Company A
            if (CarType.SelectedIndex == 0 )
            {
                  ACarType = 50;
            }
            else
            if( CarType.SelectedIndex == 1)
            {
                ACarType = 40;
            }
            else
            if (CarType.SelectedIndex == 2)
            {
                 ACarType = 25;
            }
            else
                if(CarType.SelectedIndex == 3 || CarType.SelectedIndex == 4)
            {
                 ACarType = 15;
            }
            //if statements for Company B Passengers
            int PassengerNubB = Int32.Parse(PassengersTxt.Text);
            if(PassengerNubB <= 2)
            {
                 PassengerB = 20;
            }
            else
                if(PassengerNubB >= 3 && PassengerNubB <= 6)
            {
                 PassengerB = 15;
            }
            else
                if(PassengerNubB >= 7 && PassengerNubB <= 12)
            {
                 PassengerB = 5;
            }
            //if statements for Company B CarTypes
            if (CarType.SelectedIndex == 0 || CarType.SelectedIndex == 1)
            {
                 BCarType = 40;
            }
            else
               if (CarType.SelectedIndex == 2)
            {
                 BCarType = 25;
            }
            else
               if (CarType.SelectedIndex == 3 || CarType.SelectedIndex == 4)
            {
                 BCarType = 15;
            }
            //if statements for Company C Distance
            double DistanceNubC = Convert.ToDouble(DistanceTxt.Text);
             if(DistanceNubC >= 200)
             {
                  DistanceC = 40;
             }
             else
                 if(DistanceNubC <= 199 && DistanceNubC >= 100)  
             {
                   DistanceC = 35;
             }
             else
                 if(DistanceNubC <= 99 && DistanceNubC >= 50)
             {
                   DistanceC = 25;
             }
             else
                  if(DistanceNubC <= 49 && DistanceNubC >= 10)
             {
                  DistanceC = 15;
             }
             else
                 if(DistanceNubC <= 9 && DistanceNubC >= 0)
             {
                  DistanceC = 5;
             }
            
            //Company A Calculation button
            int PassengerANumb = Int32.Parse(PassengersTxt.Text);
            int PassengerATotal = PassengerANumb * APassengers;
            //finding the passenger total for company A
            double DistanceANub = Convert.ToDouble(DistanceTxt.Text);
            double DistanceATotal = DistanceANub * ADistance;
            //fiding the distance total for company A
            double TotalA;
            TotalA = DistanceATotal + Convert.ToDouble(PassengerATotal) + Convert.ToDouble(ACarType);
            

            //Company B Calculation button
            int PassengerBTotal = PassengerNubB * PassengerB;
            //finding the passenger total for company B
            double DistanceBNub = Convert.ToDouble(DistanceTxt.Text);
            double DistanceBTotal = DistanceBNub * BDistance;
            //finding the distance total for compant B
            double TotalB;
            TotalB = DistanceBTotal + Convert.ToDouble(PassengerBTotal) + Convert.ToDouble(BCarType);
            

            //Company C Calculation button
            double PassengerCNumb = Convert.ToDouble(PassengersTxt.Text);
            double PassengerCTotal = PassengerCNumb * CPassengers;
            //finding the Passenger total for Company C
            double DistanceCTotal =  DistanceC;
            //finding the Distance Total for company C
            double TotalC;
            TotalC = DistanceCTotal + PassengerCTotal + Convert.ToDouble(CCarType);
            

            //setting up Results box
            Char LowestCost = ' ';
           if(TotalA<TotalB && TotalA < TotalC)
            {
                LowestCost = 'A';
            }
           else
                if(TotalB < TotalA && TotalB < TotalC)
            {
                LowestCost = 'B';
            }
            else
                if(TotalC < TotalA && TotalC < TotalB)
            {
                LowestCost = 'C';
            }
           else
            {
                LowestCompanyCostTxt.Text = "Tie";
            }
            //Setting up for invalid message/ displaying Lowest Company Text
           if (PassengerANumb < 1 || PassengerANumb > 12)
            { LowestCompanyCostTxt.Text = "Invalid Passenger Ammount"; }
            else
                 if (DistanceBNub < 0)
            { LowestCompanyCostTxt.Text = "Invalid Distance"; }
            else
            {
                LowestCompanyCostTxt.Text = "The lowest company cost is: " + LowestCost;
                ACostsText.Text = $"{TotalA:C}";
                BCostsText.Text = $"{TotalB:C}";
                CCostsText.Text = $"{TotalC:C}";
            }
        }
    }
}
